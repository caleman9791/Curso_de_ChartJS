# Chart.js - Smooth doughnut

A Pen created on CodePen.io. Original URL: [https://codepen.io/rozklad/pen/wPvRgW](https://codepen.io/rozklad/pen/wPvRgW).

Smooth line caps applied on Chart.js doughnut chart.